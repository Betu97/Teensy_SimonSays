#FreqCount Library#

FreqCount measures the frequency of a signal by counting the number of pulses during a fixed time.

http://www.pjrc.com/teensy/td_libs_FreqCount.html

![FreqCount and Test Equipment](http://www.pjrc.com/teensy/td_libs_FreqCount_1.jpg)
